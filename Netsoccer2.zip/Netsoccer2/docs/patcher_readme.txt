================================================================================
                           NETSOCCER2 PATCHER
================================================================================

INSTALLATION INSTRUCTIONS:
---------------------------
To use the Netsoccer Updater, copy the files "patcher.exe" and "versioncode.txt" 
to the folder of your "Netsoccer2.exe" executable.

INSTRUÇÕES DE INSTALAÇÃO:
-------------------------
Para utilizar o Netsoccer Updater, copie os arquivos "patcher.exe" e 
"versioncode.txt" para a pasta do seu executável "Netsoccer2.exe".

================================================================================

ENGLISH:
--------
WHAT IT DOES:
• Updates Netsoccer2 game automatically from GitHub
• Installs required system components (Visual C++, DirectX, DirectPlay)
• Downloads game files securely via HTTPS
• Manages DLL files automatically

HOW TO USE:
1. Run patcher.exe
2. Click "Update" button  
3. Wait for completion
4. Play the game!

REQUIREMENTS:
• Windows XP or higher
• Internet connection
• Administrator privileges recommended

LINKS:
• Game Download: https://github.com/cef20051/Netsoccer2/raw/main/Netsoccer2.exe
• Source Code: https://github.com/cef20051/Netsoccer2

================================================================================

PORTUGUÊS:
----------
O QUE FAZ:
• Atualiza o jogo Netsoccer2 automaticamente via GitHub
• Instala componentes necessários do sistema (Visual C++, DirectX, DirectPlay)
• Baixa arquivos do jogo com segurança via HTTPS
• Gerencia arquivos DLL automaticamente

COMO USAR:
1. Execute o patcher.exe
2. Clique no botão "Update"
3. Aguarde a conclusão
4. Jogue!

REQUISITOS:
• Windows XP ou superior
• Conexão com internet
• Privilégios de administrador recomendados

LINKS:
• Download do Jogo: https://github.com/cef20051/Netsoccer2/raw/main/Netsoccer2.exe
• Código Fonte: https://github.com/cef20051/Netsoccer2

================================================================================

TECHNICAL INFO / INFO TÉCNICA:

AUTOMATIC INSTALLS / INSTALAÇÕES AUTOMÁTICAS:
• Visual C++ 2005/2008/2010 Redistributables
• DirectX June 2010
• DirectPlay (Windows Feature)
• d3dx81ab.dll registration

VERSION SYSTEM / SISTEMA DE VERSÃO:
• 3-digit format (e.g., 1.0.5)
• Local: versioncode.txt
• Remote: version.txt

SECURITY / SEGURANÇA:
• HTTPS downloads only
• Official Microsoft redistributables
• Silent installation

================================================================================